import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.HashMap;
import java.util.TreeSet;
import java.util.ArrayList;

/**
 * Main class for association rule mining using apriori algorithm. 
 */
public class Generate_Association_Rules
{
	//Store transactions in transaction table, key:Tid and value:ArrayList of items
	static HashMap<Integer, ArrayList<TreeSet<Integer>>> transactionTable = new HashMap<Integer, ArrayList<TreeSet<Integer>>>();
	//Store candidate itemsets, key:Itemset, a treeSet and value:the support count of the itemset
	static HashMap<TreeSet<Integer>, Integer> candidate_itemsets = new HashMap<TreeSet<Integer>, Integer>();
	//Store all frequent itemsets
	static HashMap<TreeSet<Integer>, Integer> frequent_itemsets = new HashMap<TreeSet<Integer>, Integer>();
	//Hashmap to map unique_number to the item name.
	static HashMap<Integer, String> num_to_item_mapping = new HashMap<Integer, String>();
	
	static BufferedWriter result_file_buffered_writer;
	//Minimum support count
	static int minsup = 24;
	//Minimum confidence value
	static double minimum_confidence = 0.9;
	//Size of candidate_itemsets during frequent itemsets generation
	static int global_candidate_size = 1;
	//Number of association rules generated
	static int num_of_rules = 0;
	
	public static void main(String[] args) {
		
		try {
			File result_file = new File("result");
			FileWriter fw = new FileWriter(result_file, true);
			result_file_buffered_writer = new BufferedWriter(fw);
			result_file_buffered_writer.write("Minsup : " + minsup + " Confidence : " + minimum_confidence + "\n");
			
			generate_freq_itemsets("Output.csv");
			
			create_num_to_item_hashmap();
			generate_assoc_rules_wrapper();
			
			System.out.println("Number of rules " + num_of_rules);
			
			result_file_buffered_writer.close();
		}
		catch(Exception e){
			e.printStackTrace();
		}
	}
	
	/**
	 * During the preprocessing step every item is assigned an unique integer starting from 0.
	 * The mapping is then written to a .csv file.
	 * This function reads the .csv file and builds a hashmap with key as the unique_number and value as the item name.
	 */
	public static void create_num_to_item_hashmap()
	{
		BufferedReader reader;
		try
		{
			reader = new BufferedReader(new FileReader("dict.csv"));
			String line;
			String arr[] = new String[2];
			while((line = reader.readLine())!=null)
			{
				arr = line.split(",");
				num_to_item_mapping.put(Integer.parseInt(arr[1]), arr[0]);
			}
			reader.close();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
	/**
	 * Function to generate frequent itemsets from a list of traansactions, that have support count above some threshold value.
	 * @param csv_file_path
	 * @throws IOException
	 */
	public static void generate_freq_itemsets(String csv_file_path) throws IOException
	{
		try
		{
			create_transaction_table(csv_file_path);
		}
		catch(IOException ioe)
		{
			ioe.printStackTrace();
		}
		
		//First generate K-size itemsets, K initially set to 1.
		//Next, calculate the support count of the itemsets.
		//Remove itemsets that have low SC value.
		//Next, generate K+1 size itemsets and go to step 1.
		//Continue as long as the frequent itemsets list is not empty.
		
		do
		{
			calculate_support_count();
			filter_itemsets();
			System.out.println("candidate size " + global_candidate_size);
			for(TreeSet<Integer> t : candidate_itemsets.keySet())
			{
				result_file_buffered_writer.write(t + " (" + candidate_itemsets.get(t) + ")\n");
			}
			global_candidate_size++;
			merge_itemsets();	

		}while(!candidate_itemsets.isEmpty());
		System.out.println("DONE GENERATING FREQ ITEMSETS\n");
		
	}
	
	/**
	 * Create a transaction table hashmap with key as Transaction_id and value as list of items bought.
	 * Reads a csv file that contains transaction details.
	 * @param csv_file_path
	 * @throws IOException
	 */
	public static void create_transaction_table(String csv_file_path) throws IOException
	{
		BufferedReader reader =new BufferedReader(new FileReader(csv_file_path));
		String line = "";
		int transaction_ID = 1;
		while((line=reader.readLine())!=null)
		{
			ArrayList<TreeSet<Integer>> itemset = new ArrayList<TreeSet<Integer>>();
			String items[] = line.trim().split(",");	//fetch all items present in the transaction
			for(String item : items)
			{
				TreeSet<Integer> item_treeSet = new TreeSet<Integer>();
				item_treeSet.add(Integer.parseInt(item));
				candidate_itemsets.put(item_treeSet, 0);
				itemset.add(item_treeSet);
			}
			transactionTable.put(transaction_ID, itemset);
			transaction_ID++;
		}
		reader.close();
	}
	
	/**
	 * Function to update the support count of candidate itemsets.
	 */
	public static void calculate_support_count()
	{
		for(int transaction_index : transactionTable.keySet())
		{
			ArrayList<TreeSet<Integer>> itemset_list = transactionTable.get(transaction_index);
			for(TreeSet<Integer> itemset : itemset_list)
			{
				candidate_itemsets.put(itemset, candidate_itemsets.get(itemset)+1);
			}
		}
	}
	
	/**
	 * Remove all infrequent itemsets (itemsets that have low support count) from the list of itemsets.
	 */
	public static void filter_itemsets()
	{
		ArrayList<TreeSet<Integer>> itemsets_to_be_removed = new ArrayList<TreeSet<Integer>>(); 
		for(TreeSet<Integer> itemset : candidate_itemsets.keySet())
		{
			if(candidate_itemsets.get(itemset)<minsup) itemsets_to_be_removed .add(itemset);
			else frequent_itemsets.put(itemset, candidate_itemsets.get(itemset));
		}
		//Remove infrequent itemsets from transaction table and candidate_itemsets.
		for(int transaction_index : transactionTable.keySet())
		{
			for(TreeSet<Integer> itemset : itemsets_to_be_removed)
			{
				transactionTable.get(transaction_index).remove(itemset);
			}
		}
		for(TreeSet<Integer> itemset : itemsets_to_be_removed)
		{
			candidate_itemsets.remove(itemset);
		}
	}
	
	/**
	 * Merge K-size frequent itemsets to K+1 size itemsets.
	 */
	public static void merge_itemsets()
	{
		candidate_itemsets.clear();
		for(int transaction_id : transactionTable.keySet())
		{
			ArrayList<TreeSet<Integer>> itemset_list = transactionTable.get(transaction_id);
			ArrayList<TreeSet<Integer>> new_itemset_list = new ArrayList<TreeSet<Integer>>();
			int itemset_list_length = itemset_list.size(); 
			
			//Combine two K-size itemsets at a time
			for(int i=0;i<itemset_list_length-1;i++)
		    {                              
				for(int j=i+1;j<itemset_list_length;j++)
				{
					TreeSet<Integer> temp_itemset = new TreeSet<Integer>(itemset_list.get(i));
					temp_itemset.addAll(itemset_list.get(j));
					//Check whether the merged itemset is valid.
					if(!new_itemset_list.contains(temp_itemset) && check_itemset_validity(temp_itemset, itemset_list))
					{
						new_itemset_list.add(temp_itemset);		
						candidate_itemsets.put(temp_itemset, 0);
					}

				}
			}
			transactionTable.put(transaction_id, new_itemset_list);
		}		
	}
	
	/**
	 * Check if the itemset generated from the merge_itemset defn. is a valid itemset,ie
	 * if subsets of the itemset exist in the freq. itemsets before merging.
	 * @param Kplus1_itemset
	 * @param K_itemset_list
	 * @return
	 */
	public static boolean check_itemset_validity(TreeSet<Integer> Kplus1_itemset, ArrayList<TreeSet<Integer>> K_itemset_list)
	{
		if(Kplus1_itemset.size()!=global_candidate_size) return false;
		int K = global_candidate_size;
		int count = 0;
		for(TreeSet<Integer> old_itemset : K_itemset_list)
		{
			if(Kplus1_itemset.containsAll(old_itemset)) count++;
			if(count==K) return true;
		}
		return false;
	}
	
	/**
	 * Wrapper function to generate association rules from a list of frequent itemsets.
	 * @throws IOException
	 */
	public static void generate_assoc_rules_wrapper() throws IOException
	{
		TreeSet<Integer> lhs_rule = new TreeSet<Integer>();
		TreeSet<Integer> rhs_rule = new TreeSet<Integer>();
		for(TreeSet<Integer> itemset : frequent_itemsets.keySet())
		{
			//Itemsets of size 1
			if(itemset.size()<=1) continue;
			int itemset_size = itemset.size();
			
			//Find the subsets of the given treeSet, the subset becomes the lhs of the rule and other the rhs part of the rule.
			for(int i=0;i< (1<<itemset_size);i++)
			{
				lhs_rule = new TreeSet<Integer>(itemset);
				rhs_rule.clear();
				for(int j=0;j<itemset_size;j++)
				{	
					if((i & (1<<j))>0)
					{
						int item = find_element_in_set(j, itemset);
						lhs_rule.remove(item);
						rhs_rule.add(item);						
					}
				}
				check_confidence(itemset, lhs_rule, rhs_rule);
			}
		}
	}
	
	/**
	 * Search for an element at a given index in a treeSet, if the index exceeds the size, return -1.
	 * @param index
	 * @param set
	 * @return integer, the item in the given treeSet at a spcified index
	 */
	public static int find_element_in_set(int index, TreeSet<Integer> set)
	{
		int i = 0;
		for(Integer item : set)
		{
			if(i==index) return item;
			i++;
		}
		return -1;
	}
	
	/**
	 * Function to check if the given association rule satisfies the confidence threshold.
	 * @param itemset
	 * @param lhs_itemset
	 * @param rhs_itemset
	 * @throws IOException
	 */
	public static void check_confidence(TreeSet<Integer> itemset,TreeSet<Integer> lhs_itemset, TreeSet<Integer> rhs_itemset) throws IOException
	{
		//If lhs or rhs is empty itemset.
		if(lhs_itemset.isEmpty()) return;
		if(rhs_itemset.isEmpty()) return;
		
		double confidence = (double)frequent_itemsets.get(itemset)/frequent_itemsets.get(lhs_itemset);
		
		//If confidence value is greater than threshold, then write the rule to the result file.
		if(confidence>=minimum_confidence)
		{
			String assoc_rule;
			num_of_rules++;
			assoc_rule = "{";
			for(int item : lhs_itemset)
			{
				assoc_rule = assoc_rule + num_to_item_mapping.get(item) + ", ";
			}

			assoc_rule = assoc_rule + "} --> {";
			for(int item : rhs_itemset)
			{
				assoc_rule = assoc_rule + num_to_item_mapping.get(item) + ", ";
			}
			assoc_rule = assoc_rule + "} ";
			result_file_buffered_writer.write(assoc_rule + " (" + confidence + ")\n" );
		}
	}

}
